package mtproto

import (
	"fmt"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"

	"go.mau.fi/mautrix-telegram/pkg/gotd/bin"
)

type logType struct {
	ID   uint32
	Name string
}

func (l logType) MarshalLogObject(e zapcore.ObjectEncoder) error {
	typeIDStr := fmt.Sprintf("0x%x", l.ID)
	e.AddString("type_id", typeIDStr)
	if l.Name != "" {
		e.AddString("type_name", l.Name)
	}
	return nil
}

func (c *Conn) logWithType(b *bin.Buffer) *zap.Logger {
	id, err := b.PeekID()
	if err != nil {
		// Type info not available.
		return c.log
	}

	return c.logWithTypeID(id)
}

func (c *Conn) logWithTypeID(id uint32) *zap.Logger {
	return c.log.With(zap.Inline(logType{
		ID:   id,
		Name: c.types.Get(id),
	}))
}
