INSERT INTO "user" (bridge_id, mxid)
SELECT '', mxid FROM user_old;

DELETE FROM telethon_sessions_old WHERE auth_key IS NULL;
ALTER TABLE telethon_sessions_old ADD COLUMN json_data jsonb;
UPDATE telethon_sessions_old SET json_data=
    -- only: postgres
    jsonb_build_object
    -- only: sqlite (line commented)
--  json_object
    (
        'auth_key', encode(auth_key, 'base64'),
        'dc_id', dc_id,
        'server_address', server_address,
        'port', port
    );

INSERT INTO user_login (bridge_id, user_mxid, id, remote_name, remote_profile, space_room, metadata)
SELECT
    '', -- bridge_id
    mxid, -- user_mxid
    CAST(tgid AS TEXT), -- id
    COALESCE(tg_username, tg_phone, ''), -- remote_name
    '{}', -- remote_profile
    '', -- space_room
    -- only: postgres
    jsonb_build_object
    -- only: sqlite (line commented)
--  json_object
    (
        'phone', COALESCE('+' || tg_phone, ''),
        'session', json((SELECT json_data FROM telethon_sessions_old WHERE session_id=mxid))
    ) -- metadata
FROM user_old
WHERE tgid IS NOT NULL;

INSERT INTO ghost (
    bridge_id, id, name, avatar_id, avatar_hash, avatar_mxc,
    name_set, avatar_set, contact_info_set, is_bot, identifiers, metadata
)
SELECT
    '', -- bridge_id
    CAST(id AS TEXT), -- id
    COALESCE(displayname, ''), -- name
    COALESCE(photo_id, ''), -- avatar_id
    '', -- avatar_hash
    COALESCE(avatar_url, ''), -- avatar_mxc
    name_set,
    avatar_set,
    contact_info_set,
    COALESCE(is_bot, false),
    '[]', -- identifiers
    -- only: postgres
    jsonb_build_object
    -- only: sqlite (line commented)
--  json_object
    (
        'is_premium', CASE WHEN is_premium THEN json('true') ELSE json('false') END,
        'is_channel', CASE WHEN is_channel THEN json('true') ELSE json('false') END,
        'contact_source', displayname_source,
        'source_is_contact', CASE WHEN displayname_contact THEN json('true') ELSE json('false') END
    ) -- metadata
FROM puppet_old;

DELETE FROM user_portal_old WHERE portal IN (SELECT tgid FROM portal_old WHERE peer_type<>'channel');
DELETE FROM backfill_queue_old WHERE portal_tgid IN (SELECT tgid FROM portal_old WHERE peer_type<>'channel');

UPDATE portal_old
SET tg_receiver=COALESCE((SELECT "user" FROM user_portal_old WHERE portal=portal_old.tgid LIMIT 1), tg_receiver)
WHERE peer_type='chat' AND tgid=tg_receiver;

UPDATE portal_old
SET tg_receiver=COALESCE((SELECT tgid FROM user_old WHERE tgid IS NOT NULL LIMIT 1), tg_receiver)
WHERE peer_type='chat' AND tgid=tg_receiver;

DELETE FROM portal_old WHERE peer_type='chat' AND tgid=tg_receiver;

INSERT INTO portal (
    bridge_id, id, receiver, mxid, other_user_id, name, topic, avatar_id, avatar_hash, avatar_mxc,
    name_set, avatar_set, topic_set, name_is_custom, in_space, room_type, metadata
)
SELECT
    '', -- bridge_id
    peer_type || ':' || CAST(tgid AS TEXT), -- id
    CASE WHEN peer_type='channel' THEN '' ELSE CAST(tg_receiver AS TEXT) END, -- receiver
    mxid, -- mxid
    CASE WHEN peer_type='user' THEN CAST(tgid AS TEXT) END, -- other_user_id
    COALESCE(title, ''), -- name
    COALESCE(about, ''), -- topic
    COALESCE(photo_id, ''), -- avatar_id
    '', -- avatar_hash
    COALESCE(avatar_url, ''), -- avatar_mxc
    name_set, -- name_set
    avatar_set, -- avatar_set
    false, -- topic_set
    peer_type<>'user', -- name_is_custom
    false, -- in_space
    CASE WHEN peer_type='user' THEN 'dm' ELSE '' END, -- room_type
    -- only: postgres
    jsonb_build_object
    -- only: sqlite (line commented)
--  json_object
    (
        'is_supergroup', CASE WHEN megagroup THEN json('true') ELSE json('false') END
    ) -- metadata
FROM portal_old;

INSERT INTO user_portal (bridge_id, user_mxid, login_id, portal_id, portal_receiver, in_space, preferred)
SELECT
    '', -- bridge_id
    user_old.mxid, -- user_mxid
    CAST(user_portal_old.user AS TEXT), -- login_id
    portal_old.peer_type || ':' || CAST(user_portal_old.portal AS TEXT), -- portal_id
    CASE WHEN peer_type='channel' THEN '' ELSE CAST(user_portal_old.portal_receiver AS TEXT) END, -- portal_receiver
    false, -- in_space
    false -- preferred
FROM user_portal_old
INNER JOIN user_old ON user_portal_old."user" = user_old.tgid
INNER JOIN portal_old ON user_portal_old.portal = portal_old.tgid and user_portal_old.portal_receiver = portal_old.tg_receiver;

INSERT INTO user_portal (bridge_id, user_mxid, login_id, portal_id, portal_receiver, in_space, preferred)
SELECT
    '', -- bridge_id
    user_old.mxid, -- user_mxid
    CAST(portal_old.tg_receiver AS TEXT), -- login_id
    portal_old.peer_type || ':' || CAST(portal_old.tgid AS TEXT), -- portal_id
    CAST(portal_old.tg_receiver AS TEXT), -- portal_receiver
    false, -- in_space
    false -- preferred
FROM portal_old
INNER JOIN user_old ON portal_old.tg_receiver = user_old.tgid
WHERE portal_old.tg_receiver<>portal_old.tgid
ON CONFLICT (bridge_id, user_mxid, login_id, portal_id, portal_receiver) DO NOTHING;

INSERT INTO ghost (bridge_id, id, name, avatar_id, avatar_hash, avatar_mxc, name_set, avatar_set, contact_info_set, is_bot, identifiers, metadata)
VALUES ('', '', '', '', '', '', false, false, false, false, '[]', '{}');

UPDATE message_old SET sender=NULL WHERE sender IS NOT NULL AND NOT EXISTS(SELECT 1 FROM puppet_old WHERE id=sender);

INSERT INTO message (
    bridge_id, id, part_id, mxid, room_id, room_receiver, sender_id, sender_mxid, timestamp, edit_count, metadata
)
SELECT
    '', -- bridge_id
    CASE WHEN tg_space=portal_old.tgid THEN (CAST(tg_space AS TEXT) || '.') ELSE '' END || CAST(message_old.tgid AS TEXT), -- id
    '', -- part_id
    message_old.mxid, -- mxid
    portal_old.peer_type || ':' || CAST(portal_old.tgid AS TEXT), -- room_id
    CASE WHEN portal_old.peer_type='channel' THEN '' ELSE CAST(portal_old.tg_receiver AS TEXT) END, -- room_receiver
    COALESCE(CAST(sender AS TEXT), ''), -- sender_id
    COALESCE(sender_mxid, ''),
    0, -- timestamp
    0, -- edit_count
    -- only: postgres
    jsonb_build_object
    -- only: sqlite (line commented)
--  json_object
    (
        'content_hash', CASE WHEN content_hash IS NULL THEN '' ELSE encode(content_hash, 'base64') END
    ) -- metadata
FROM message_old
INNER JOIN portal_old ON mx_room=portal_old.mxid
WHERE (tg_space=portal_old.tgid OR tg_space=portal_old.tg_receiver) AND edit_index=0;
-- TODO migrate edit_index?

INSERT INTO reaction (
    bridge_id, message_id, message_part_id, sender_id, emoji_id, room_id, room_receiver, mxid, timestamp, emoji, metadata
)
SELECT
    '', -- bridge_id
    message.id, -- message_id
    message.part_id, -- message_part_id
    CAST(tg_sender AS TEXT), -- sender_id
    reaction, -- emoji_id
    message.room_id, -- room_id
    message.room_receiver, -- room_receiver
    reaction_old.mxid, -- mxid
    0, -- timestamp
    reaction, -- emoji
    '{}' -- metadata
FROM reaction_old
INNER JOIN message ON reaction_old.msg_mxid=message.mxid;

INSERT INTO telegram_access_hash (user_id, entity_type, entity_id, access_hash)
SELECT
    user_old.tgid,
    CASE WHEN id < 0 THEN 'channel' ELSE 'user' END,
    CASE WHEN id < 0 THEN -id - 1000000000000 ELSE id END,
    hash
FROM telethon_entities_old
LEFT JOIN user_old ON user_old.mxid=session_id
WHERE user_old.tgid IS NOT NULL AND hash<>0;

INSERT INTO telegram_user_state (user_id, pts, qts, date, seq)
SELECT user_old.tgid, pts, qts, date, seq
FROM telethon_update_state_old
LEFT JOIN user_old ON user_old.mxid=session_id
WHERE entity_id=0 AND user_old.tgid IS NOT NULL;

INSERT INTO telegram_channel_state (user_id, channel_id, pts)
SELECT user_old.tgid, entity_id, pts
FROM telethon_update_state_old
LEFT JOIN user_old ON user_old.mxid=session_id
WHERE entity_id<>0 AND user_old.tgid IS NOT NULL;

INSERT INTO telegram_username (username, entity_type, entity_id)
SELECT
    username,
    CASE WHEN id < 0 THEN 'channel' ELSE 'user' END,
    CASE WHEN id < 0 THEN -id - 1000000000000 ELSE id END
FROM telethon_entities_old
WHERE username<>''
ON CONFLICT DO NOTHING;

INSERT INTO telegram_phone_number (phone_number, entity_id)
SELECT phone, id
FROM telethon_entities_old
WHERE phone<>''
ON CONFLICT DO NOTHING;

INSERT INTO telegram_file (id, mxc, mime_type, size, width, height, timestamp)
SELECT id, mxc, mime_type, size, width, height, timestamp
FROM telegram_file_old;

INSERT INTO disappearing_message (bridge_id, mx_room, mxid, type, timer, disappear_at)
SELECT
    '', -- bridge_id
    room_id,
    event_id,
    'after_send',
    expiration_seconds * 1000000000,
    expiration_ts * 1000000
FROM disappearing_message_old
WHERE expiration_ts<9999999999999 AND expiration_seconds<999999
  AND room_id IN (SELECT mxid FROM portal WHERE mxid IS NOT NULL);

-- TODO do something with the bot_chat table?

-- Python -> Go mx_ table migration
-- only: postgres until "end only"
ALTER TABLE mx_room_state DROP COLUMN is_encrypted;
ALTER TABLE mx_room_state RENAME COLUMN has_full_member_list TO members_fetched;
UPDATE mx_room_state SET members_fetched=false WHERE members_fetched IS NULL;
ALTER TABLE mx_room_state ADD COLUMN join_rules jsonb;

ALTER TABLE mx_room_state ALTER COLUMN power_levels TYPE jsonb USING power_levels::jsonb;
ALTER TABLE mx_room_state ALTER COLUMN encryption TYPE jsonb USING encryption::jsonb;
ALTER TABLE mx_room_state ALTER COLUMN create_event TYPE jsonb USING create_event::jsonb;
ALTER TABLE mx_room_state ALTER COLUMN members_fetched SET DEFAULT false;
ALTER TABLE mx_room_state ALTER COLUMN members_fetched SET NOT NULL;
-- end only postgres
-- only: sqlite until "end only"
CREATE TABLE new_mx_room_state (
    room_id         TEXT PRIMARY KEY,
    power_levels    jsonb,
    encryption      jsonb,
    create_event    jsonb,
    join_rules      jsonb,
    members_fetched BOOLEAN NOT NULL DEFAULT false
);

INSERT INTO new_mx_room_state (room_id, encryption, power_levels, create_event, members_fetched)
SELECT room_id, encryption, power_levels, create_event, COALESCE(has_full_member_list, false)
FROM mx_room_state;

DROP TABLE mx_room_state;
ALTER TABLE new_mx_room_state RENAME TO mx_room_state;
-- end only sqlite

ALTER TABLE mx_user_profile ADD COLUMN name_skeleton bytea;
CREATE INDEX mx_user_profile_membership_idx ON mx_user_profile (room_id, membership);
CREATE INDEX mx_user_profile_name_skeleton_idx ON mx_user_profile (room_id, name_skeleton);

UPDATE mx_user_profile SET displayname='' WHERE displayname IS NULL;
UPDATE mx_user_profile SET avatar_url='' WHERE avatar_url IS NULL;

CREATE TABLE mx_registrations (
    user_id TEXT PRIMARY KEY
);

UPDATE mx_version SET version=10;
DELETE FROM mx_user_profile WHERE room_id='' OR user_id='';
DELETE FROM mx_room_state WHERE room_id='';

DROP TABLE user_portal_old;
DROP TABLE backfill_queue_old;
DROP TABLE bot_chat_old;
DROP TABLE contact_old;
DROP TABLE disappearing_message_old;
DROP TABLE message_old;
DROP TABLE reaction_old;
DROP TABLE portal_old;
DROP TABLE puppet_old;
DROP TABLE user_old;
-- only: postgres (this is deleted separately for sqlite)
DROP TABLE telegram_file_old;
DROP TABLE telethon_entities_old;
DROP TABLE telethon_sent_files_old;
DROP TABLE telethon_sessions_old;
DROP TABLE telethon_update_state_old;
